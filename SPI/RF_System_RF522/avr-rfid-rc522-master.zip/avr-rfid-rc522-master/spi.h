void spi_master_init(void);
char spi_master_tranceiver(char data);
